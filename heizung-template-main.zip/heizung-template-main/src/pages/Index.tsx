import Header from "@/components/Header";
import Hero from "@/components/Hero";
import BentoServices from "@/components/BentoServices";
import Timeline from "@/components/Timeline";
import QuickContact from "@/components/QuickContact";
import Testimonials from "@/components/Testimonials";
import Career from "@/components/Career";
import FAQ from "@/components/FAQ";
import AboutUs from "@/components/AboutUs";
import Footer from "@/components/Footer";
import useSEO from "@/hooks/useSEO";

const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Beispielfirma",
  "description": "Ihr Meisterbetrieb für Heizung, Sanitär und erneuerbare Energien. Heizungsinstallation, Wartung, Wärmepumpen und 24h Notdienst.",
  "url": "https://beispielfirma.de",
  "telephone": "+49-123-456789",
  "email": "info@beispielfirma.de",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Musterstraße 12",
    "addressLocality": "Musterstadt",
    "postalCode": "12345",
    "addressCountry": "DE"
  },
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Heizung & Sanitär",
    "itemListElement": [
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Heizungsinstallation & -austausch" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Wartung & Inspektion" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Badsanierung" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Wärmepumpen & erneuerbare Energien" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "24h Notdienst" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Solarthermie" } },
    ]
  }
};

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Wie oft sollte eine Heizung gewartet werden?",
      "acceptedAnswer": { "@type": "Answer", "text": "Einmal jährlich – idealerweise vor der Heizsaison. Eine jährliche Wartung sorgt für optimale Effizienz und verlängert die Lebensdauer der Anlage." }
    },
    {
      "@type": "Question",
      "name": "Welche Fördermittel gibt es für eine neue Heizung?",
      "acceptedAnswer": { "@type": "Answer", "text": "Bis zu 70 % Förderung durch BEG und KfW möglich. Je nach Maßnahme und persönlicher Situation können Sie Zuschüsse oder günstige Kredite erhalten." }
    },
    {
      "@type": "Question",
      "name": "Wie schnell sind Sie im Notfall vor Ort?",
      "acceptedAnswer": { "@type": "Answer", "text": "In der Regel innerhalb von 1–2 Stunden. Unser 24h-Notdienst ist rund um die Uhr erreichbar." }
    },
    {
      "@type": "Question",
      "name": "Lohnt sich eine Wärmepumpe für mein Haus?",
      "acceptedAnswer": { "@type": "Answer", "text": "In den meisten Fällen ja – besonders bei guter Dämmung. Wärmepumpen arbeiten besonders effizient in gut gedämmten Gebäuden mit Fußbodenheizung." }
    },
    {
      "@type": "Question",
      "name": "Wie lange dauert ein Heizungstausch?",
      "acceptedAnswer": { "@type": "Answer", "text": "In der Regel 2–5 Werktage. Der genaue Zeitrahmen hängt von der Anlage und den baulichen Gegebenheiten ab." }
    },
    {
      "@type": "Question",
      "name": "Bieten Sie auch Badsanierungen an?",
      "acceptedAnswer": { "@type": "Answer", "text": "Ja – vom barrierefreien Umbau bis zur Komplettsanierung. Wir planen und realisieren Ihr neues Bad inklusive Sanitärinstallation." }
    }
  ]
};

const Index = () => {
  useSEO({
    title: "Heizungsbauer Musterstadt | Beispielfirma – Meisterbetrieb für Heizung & Sanitär",
    description: "Ihr Meisterbetrieb für Heizungsinstallation, Wartung, Wärmepumpen und 24h Notdienst. Jetzt kostenlos Angebot anfordern!",
    canonical: "https://beispielfirma.de/",
  });

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <BentoServices />
        <Timeline />
        <QuickContact />
        <Testimonials />
        <Career />
        <FAQ />
        <AboutUs />
      </main>
      <Footer />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
    </div>
  );
};

export default Index;
