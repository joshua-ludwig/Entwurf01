import { Link } from "react-router-dom";
import QuickContact from "@/components/QuickContact";
import Footer from "@/components/Footer";
import useSEO from "@/hooks/useSEO";
import { Flame } from "lucide-react";

const Kontakt = () => {
  useSEO({
    title: "Kontakt & Angebot anfordern | Beispielfirma – Heizungsbauer",
    description: "Kostenloses Angebot für Heizungsinstallation, Wartung oder Badsanierung anfordern. Beispielfirma – Ihr Meisterbetrieb.",
    canonical: "https://beispielfirma.de/kontakt",
  });

  return (
    <div className="min-h-screen">
      <header className="border-b border-gray-200 bg-white py-4">
        <div className="container">
          <Link to="/" className="flex items-center gap-2">
            <Flame className="h-8 w-8 text-primary" />
            <span className="font-display text-xl font-bold md:text-2xl">Beispielfirma</span>
          </Link>
        </div>
      </header>

      <main>
        <QuickContact />
      </main>

      <Footer />
    </div>
  );
};

export default Kontakt;
