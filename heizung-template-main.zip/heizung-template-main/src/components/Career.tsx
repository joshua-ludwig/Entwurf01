import { motion } from "framer-motion";
import { GraduationCap, Clock, Banknote } from "lucide-react";
import { Button } from "@/components/ui/button";

const benefits = [
  { icon: GraduationCap, title: "Weiterbildung & Schulungen", desc: "Regelmäßige Fortbildungen zu neuer Heiztechnik, Wärmepumpen und erneuerbaren Energien." },
  { icon: Clock, title: "Flexible Arbeitszeiten", desc: "Arbeitszeitmodelle, die zu Ihrem Leben passen – keine Wochenendarbeit." },
  { icon: Banknote, title: "Übertarifliche Vergütung", desc: "Attraktive Bezahlung, Firmenwagen und betriebliche Altersvorsorge." },
];

const Career = () => {
  return (
    <section id="karriere" className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <h2 className="text-3xl font-bold md:text-4xl">Werde Teil des Teams</h2>
          <p className="mt-3 text-muted-foreground">
            Wir suchen engagierte SHK-Fachkräfte, Meister und Auszubildende
          </p>
        </motion.div>

        <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-3">
          {benefits.map((b, i) => (
            <motion.div
              key={b.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{
                y: -8,
                borderColor: "hsl(24, 95%, 48%)",
                boxShadow: "0 20px 40px -12px hsla(24, 95%, 48%, 0.15)",
                transition: { duration: 0.15 },
              }}
              style={{ borderColor: "#d1d5db" }}
              className="rounded-xl border bg-gray-50 p-6 text-center"
            >
              <b.icon className="mx-auto mb-4 h-10 w-10 text-primary" />
              <h3 className="mb-2 font-sans text-lg font-semibold">{b.title}</h3>
              <p className="text-sm text-muted-foreground">{b.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button variant="outline" size="lg" asChild>
            <a href="mailto:info@beispielfirma.de?subject=Initiativbewerbung">
              Initiativbewerbung
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Career;
