import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Thomas Weber",
    position: "Hausbesitzer, Musterstadt",
    quote: "Unsere neue Wärmepumpe läuft seit einem Jahr einwandfrei. Die Beratung war top und die Installation sauber und termingerecht.",
  },
  {
    name: "Sandra Klein",
    position: "Hausverwaltung Klein & Partner",
    quote: "Beispielfirma betreut die Heizungsanlagen unserer Mehrfamilienhäuser. Der 24h-Notdienst gibt uns und unseren Mietern Sicherheit.",
  },
  {
    name: "Dr. Martin Becker",
    position: "Praxisinhaber, Ärztehaus Musterstadt",
    quote: "Die Badsanierung war in zwei Wochen erledigt – termingerecht und ohne Überraschungen. Sehr professionelles Team.",
  },
  {
    name: "Petra Hoffmann",
    position: "Eigenheimbesitzerin",
    quote: "Dank der Fördermittelberatung haben wir beim Heizungstausch über 10.000 € gespart. Vielen Dank für die kompetente Unterstützung!",
  },
];

const Testimonials = () => {
  return (
    <section className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <h2 className="text-3xl font-bold md:text-4xl">Das sagen unsere Kunden</h2>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{
                y: -8,
                borderColor: "hsl(24, 95%, 48%)",
                boxShadow: "0 20px 40px -12px hsla(24, 95%, 48%, 0.15)",
                transition: { duration: 0.15 },
              }}
              style={{ borderColor: "#d1d5db" }}
              className="rounded-xl border bg-gray-50 p-6"
            >
              <div className="mb-4 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-lg font-bold text-primary">
                  {t.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <p className="font-semibold">{t.name}</p>
                  <p className="text-sm text-muted-foreground">{t.position}</p>
                </div>
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-accent text-accent" />
                  ))}
                </div>
              </div>
              <p className="text-muted-foreground italic">"{t.quote}"</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
