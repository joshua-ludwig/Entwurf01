import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Flame } from "lucide-react";

const navItems = [
  { label: "Leistungen", href: "#leistungen" },
  { label: "Ablauf", href: "#ablauf" },
  { label: "Karriere", href: "#karriere" },
  { label: "FAQ", href: "#faq" },
];

const Header = () => {
  const location = useLocation();

  const handleLogoClick = (e: React.MouseEvent) => {
    if (location.pathname === "/") {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "instant" });
    }
  };

  return (
    <header className="sticky top-0 z-50 border-b border-gray-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80">
      <div className="container flex h-16 items-center justify-between md:h-20">
        <Link to="/" onClick={handleLogoClick} className="flex items-center gap-2 shrink-0 min-w-0">
          <Flame className="h-7 w-7 md:h-8 md:w-8 text-primary shrink-0" />
          <span className="font-display text-lg font-bold md:text-2xl truncate">Beispielfirma</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-foreground/80 transition-colors hover:text-primary"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <Button asChild size="sm" className="md:size-default">
          <Link to="/kontakt"><span className="md:hidden">Angebot</span><span className="hidden md:inline">Angebot anfordern</span></Link>
        </Button>
      </div>
    </header>
  );
};

export default Header;
