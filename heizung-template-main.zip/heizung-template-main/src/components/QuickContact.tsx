import { useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Send, Shield, Award, BadgeCheck, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ReactNode } from "react";

const trustItems: { icon: typeof Shield; label: ReactNode }[] = [
  { icon: Shield, label: "Meisterbetrieb" },
  { icon: Award, label: "SHK-Fachbetrieb" },
  { icon: MapPin, label: "Kostenlose Erstberatung" },
  { icon: BadgeCheck, label: "Unverbindliches Angebot" },
];

const QuickContact = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [privacy, setPrivacy] = useState(false);
  const [form, setForm] = useState({
    name: "", firma: "", email: "", telefon: "", anliegen: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.anliegen) {
      toast({ title: "Bitte Pflichtfelder ausfüllen", variant: "destructive" });
      return;
    }
    if (!privacy) {
      toast({ title: "Bitte Datenschutzerklärung akzeptieren", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke("send-contact-email", {
        body: { name: form.name, email: form.email, firma: form.firma, telefon: form.telefon, objektart: form.anliegen },
      });
      if (error) throw error;
      toast({ title: "Anfrage gesendet!", description: "Wir melden uns in Kürze." });
      setForm({ name: "", firma: "", email: "", telefon: "", anliegen: "" });
      setPrivacy(false);
    } catch {
      toast({ title: "Fehler beim Senden", description: "Bitte versuchen Sie es erneut.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative mx-auto max-w-5xl overflow-hidden rounded-3xl border border-gray-300 bg-gray-50 p-8 md:p-12"
        >
          {/* Mesh gradient blobs inside the box */}
          <div className="pointer-events-none absolute -left-16 -top-16 h-56 w-56 rounded-full bg-primary opacity-[0.05] blur-3xl" />
          <div className="pointer-events-none absolute -bottom-16 -right-16 h-56 w-56 rounded-full bg-accent opacity-[0.1] blur-3xl" />

          <h2 className="mb-2 text-center text-3xl font-bold">Kostenlos Angebot anfordern</h2>
          <p className="mb-8 text-center text-muted-foreground">
            In 30 Sekunden zur unverbindlichen Anfrage
          </p>

          <div className="grid items-start gap-10 md:grid-cols-2">
            {/* Left: Form */}
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div>
                <label className="mb-1 block text-sm font-medium">Name *</label>
                <Input placeholder="Max Mustermann" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">Firma</label>
                <Input placeholder="Firma GmbH" value={form.firma} onChange={(e) => setForm({ ...form, firma: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">E-Mail *</label>
                <Input type="email" placeholder="max@firma.de" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">Telefon</label>
                <Input placeholder="0123 456789" value={form.telefon} onChange={(e) => setForm({ ...form, telefon: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">Anliegen *</label>
                <Select onValueChange={(v) => setForm({ ...form, anliegen: v })} value={form.anliegen}>
                  <SelectTrigger><SelectValue placeholder="Bitte wählen..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="heizungstausch">Heizungstausch</SelectItem>
                    <SelectItem value="wartung">Wartung & Inspektion</SelectItem>
                    <SelectItem value="waermepumpe">Wärmepumpe</SelectItem>
                    <SelectItem value="badsanierung">Badsanierung</SelectItem>
                    <SelectItem value="notdienst">Notdienst</SelectItem>
                    <SelectItem value="solarthermie">Solarthermie</SelectItem>
                    <SelectItem value="sonstiges">Sonstiges</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <label className="flex cursor-pointer items-start gap-3 rounded-lg p-3 -mx-3 transition-colors hover:bg-gray-100">
                <Checkbox
                  checked={privacy}
                  onCheckedChange={(v) => setPrivacy(v === true)}
                  className="mt-0.5"
                />
                <span className="text-sm text-muted-foreground">
                  Ich stimme der Verarbeitung meiner Daten gemäß der{" "}
                  <a href="#" className="font-medium text-primary underline">Datenschutzerklärung</a> zu. *
                </span>
              </label>

              <Button type="submit" disabled={loading} size="lg" className="mt-2 w-full gap-2">
                <Send className="h-4 w-4" />
                {loading ? "Wird gesendet..." : "Jetzt anfragen"}
              </Button>
            </form>

            {/* Right: Trust */}
            <div className="flex flex-col">
              <h3 className="mb-6 font-sans text-xl font-semibold">Warum Beispielfirma?</h3>
              <div className="flex flex-col gap-5">
                {trustItems.map((item, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <item.icon className="h-5 w-5 text-primary" />
                    </div>
                    <span className="font-medium">{item.label}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8 rounded-lg border border-gray-300 bg-white p-4">
                <p className="text-sm text-muted-foreground">
                  <strong className="text-foreground">Meisterbetrieb</strong> – kompetente Beratung, fachgerechte Installation und zuverlässiger Service aus einer Hand.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default QuickContact;
