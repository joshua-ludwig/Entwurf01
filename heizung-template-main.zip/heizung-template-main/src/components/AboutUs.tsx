import { motion } from "framer-motion";
import { Target, Cpu } from "lucide-react";

const cards = [
  {
    icon: Target,
    title: "Unser Anspruch",
    desc: "Qualität, Zuverlässigkeit und Kundenzufriedenheit stehen bei uns an erster Stelle. Als Meisterbetrieb setzen wir auf fachgerechte Arbeit und transparente Kommunikation – von der ersten Beratung bis zur Abnahme.",
  },
  {
    icon: Cpu,
    title: "Moderne Technik",
    desc: "Wir setzen auf innovative Heiztechnik und erneuerbare Energien. Von hocheffizienten Wärmepumpen bis hin zu smarten Thermostat-Lösungen – wir bringen Ihr Zuhause auf den neuesten Stand.",
  },
];

const AboutUs = () => {
  return (
    <section className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <h2 className="text-3xl font-bold md:text-4xl">Über uns</h2>
          <p className="mt-3 text-muted-foreground">
            Ihr Heizungsbauer mit Erfahrung und Leidenschaft
          </p>
        </motion.div>

        <div className="mx-auto grid max-w-4xl gap-8 md:grid-cols-2">
          {cards.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              whileHover={{
                y: -8,
                borderColor: "hsl(24, 95%, 48%)",
                boxShadow: "0 20px 40px -12px hsla(24, 95%, 48%, 0.15)",
                transition: { duration: 0.15 },
              }}
              style={{ borderColor: "#d1d5db" }}
              className="rounded-xl border bg-gray-50 p-8"
            >
              <c.icon className="mb-4 h-10 w-10 text-primary" />
              <h3 className="mb-3 font-sans text-xl font-semibold">{c.title}</h3>
              <p className="text-muted-foreground">{c.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
