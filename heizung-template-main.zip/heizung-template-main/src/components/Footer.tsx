import { Link } from "react-router-dom";
import { Phone, MapPin, Mail, Flame } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-950 py-12 text-white">
      <div className="container grid gap-8 md:grid-cols-3">
        <div>
          <div className="mb-4 flex items-center gap-2">
            <Flame className="h-8 w-8 text-primary" />
            <span className="font-display text-xl font-bold">Beispielfirma</span>
          </div>
          <p className="text-sm text-white/70">
            Ihr Meisterbetrieb für Heizung, Sanitär und erneuerbare Energien.
          </p>
        </div>

        <div>
          <h4 className="mb-4 font-sans text-lg font-semibold">Kontakt</h4>
          <div className="flex flex-col gap-3 text-sm text-white/70">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 shrink-0" />
              Musterstraße 12, 12345 Musterstadt
            </div>
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 shrink-0" />
              0123 456789
            </div>
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 shrink-0" />
              info@beispielfirma.de
            </div>
          </div>
        </div>

        <div>
          <h4 className="mb-4 font-sans text-lg font-semibold">Rechtliches</h4>
          <div className="flex flex-col gap-2 text-sm text-white/70">
            <Link to="#" className="transition-colors hover:text-white">
              Impressum
            </Link>
            <Link to="#" className="transition-colors hover:text-white">
              Datenschutz
            </Link>
          </div>
        </div>
      </div>

      <div className="container mt-8 border-t border-white/10 pt-6 text-center text-xs text-white/50">
        © {new Date().getFullYear()} Beispielfirma. Alle Rechte vorbehalten.
      </div>
    </footer>
  );
};

export default Footer;
