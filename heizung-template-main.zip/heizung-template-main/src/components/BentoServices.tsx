import { motion } from "framer-motion";
import { Wrench, ClipboardCheck, Bath, Leaf, Phone, Sun, CheckCircle2 } from "lucide-react";
import bentoHeizung from "@/assets/bento-heizung.jpg";
import bentoWaermepumpe from "@/assets/bento-waermepumpe.jpg";
import bentoNotdienst from "@/assets/bento-notdienst.jpg";

const hoverEffect = {
  y: -8,
  borderColor: "hsl(24, 95%, 48%)",
  boxShadow: "0 20px 40px -12px hsla(24, 95%, 48%, 0.15)",
  transition: { duration: 0.15 },
};

const BentoCard = ({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.4, delay }}
    whileHover={hoverEffect}
    style={{ borderColor: "#d1d5db" }}
    className={`overflow-hidden rounded-2xl border bg-gray-50 ${className}`}
  >
    {children}
  </motion.div>
);

const CheckItem = ({ text }: { text: string }) => (
  <div className="flex items-center gap-2.5 text-[15px] text-muted-foreground">
    <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
    {text}
  </div>
);

const BentoServices = () => {
  return (
    <section id="leistungen" className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <h2 className="text-3xl font-bold md:text-4xl">Unsere Leistungen</h2>
          <p className="mt-3 text-muted-foreground">
            Alles rund um Heizung, Sanitär und erneuerbare Energien
          </p>
        </motion.div>

        <div className="grid gap-4 md:grid-cols-3">
          {/* Row 1: Heizung (2col) + Wartung (1col) */}
          <BentoCard className="md:col-span-2" delay={0}>
            <div className="grid h-full md:grid-cols-2">
              <div className="flex flex-col justify-start p-6 md:p-8">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <Wrench className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-3 font-sans text-2xl font-semibold">Heizungsinstallation & -austausch</h3>
                <p className="mb-5 text-[15px] text-muted-foreground">
                  Moderne Heiztechnik für Ihr Zuhause – von der Beratung bis zur Inbetriebnahme.
                </p>
                <div className="flex flex-col gap-2">
                  <CheckItem text="Gas- & Öl-Brennwerttechnik" />
                  <CheckItem text="Fußbodenheizung" />
                  <CheckItem text="Heizkörpertausch" />
                </div>
              </div>
              <div className="hidden md:block">
                <img
                  src={bentoHeizung}
                  alt="Heizungsinstallation"
                  className="h-full w-full object-cover"
                  loading="lazy"
                  width={800}
                  height={512}
                />
              </div>
            </div>
          </BentoCard>

          <BentoCard className="p-6 md:p-8" delay={0.05}>
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <ClipboardCheck className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-3 font-sans text-2xl font-semibold">Wartung & Inspektion</h3>
            <p className="mb-5 text-[15px] text-muted-foreground">
              Regelmäßige Wartung sichert Effizienz und verlängert die Lebensdauer Ihrer Anlage.
            </p>
            <div className="flex flex-col gap-2.5">
              <CheckItem text="Jährliche Heizungswartung" />
              <CheckItem text="Störungsdiagnose" />
              <CheckItem text="Abgasmessung" />
            </div>
          </BentoCard>

          {/* Row 2: Badsanierung (1col) + Wärmepumpen (2col) */}
          <BentoCard className="p-6 md:p-8" delay={0.1}>
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <Bath className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-3 font-sans text-2xl font-semibold">Badsanierung</h3>
            <p className="mb-5 text-[15px] text-muted-foreground">
              Vom barrierefreien Umbau bis zur Komplettsanierung – Ihr Traumbad aus einer Hand.
            </p>
            <div className="flex flex-col gap-2.5">
              <CheckItem text="Barrierefreie Bäder" />
              <CheckItem text="Sanitärinstallation" />
              <CheckItem text="Armaturen & Keramik" />
            </div>
          </BentoCard>

          <BentoCard className="md:col-span-2" delay={0.15}>
            <div className="grid h-full md:grid-cols-2">
              <div className="flex flex-col justify-start p-6 md:p-8">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <Leaf className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-3 font-sans text-2xl font-semibold">Wärmepumpen & erneuerbare Energien</h3>
                <p className="mb-5 text-[15px] text-muted-foreground">
                  Zukunftssichere Heizsysteme – nachhaltig, effizient und förderfähig.
                </p>
                <div className="flex flex-col gap-2">
                  <CheckItem text="Luft-Wasser-Wärmepumpen" />
                  <CheckItem text="Fördermittelberatung" />
                  <CheckItem text="Hybridlösungen" />
                </div>
              </div>
              <div className="hidden md:block">
                <img
                  src={bentoWaermepumpe}
                  alt="Wärmepumpe an Einfamilienhaus"
                  className="h-full w-full object-cover"
                  loading="lazy"
                  width={800}
                  height={512}
                />
              </div>
            </div>
          </BentoCard>

          {/* Row 3: Notdienst (2col) + Solarthermie (1col) */}
          <BentoCard className="md:col-span-2" delay={0.2}>
            <div className="grid h-full md:grid-cols-2">
              <div className="flex flex-col justify-start p-6 md:p-8">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-3 font-sans text-2xl font-semibold">24h Notdienst</h3>
                <p className="mb-5 text-[15px] text-muted-foreground">
                  Heizung ausgefallen? Wir sind rund um die Uhr für Sie da – schnell und zuverlässig.
                </p>
                <div className="flex flex-col gap-2">
                  <CheckItem text="Soforthilfe bei Heizungsausfall" />
                  <CheckItem text="Rohrbruch & Wasserschäden" />
                  <CheckItem text="Notfall-Hotline" />
                </div>
              </div>
              <div className="hidden md:block">
                <img
                  src={bentoNotdienst}
                  alt="24h Notdienst Fahrzeug"
                  className="h-full w-full object-cover"
                  loading="lazy"
                  width={800}
                  height={512}
                />
              </div>
            </div>
          </BentoCard>

          <BentoCard className="p-6 md:p-8" delay={0.25}>
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <Sun className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-3 font-sans text-2xl font-semibold">Solarthermie</h3>
            <p className="mb-5 text-[15px] text-muted-foreground">
              Nutzen Sie die Kraft der Sonne zur Warmwasserbereitung und Heizungsunterstützung.
            </p>
            <div className="flex flex-col gap-2.5">
              <CheckItem text="Flach- & Röhrenkollektoren" />
              <CheckItem text="Kombination mit Heizung" />
              <CheckItem text="Staatliche Förderung" />
            </div>
          </BentoCard>
        </div>
      </div>
    </section>
  );
};

export default BentoServices;
