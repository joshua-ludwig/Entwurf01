import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Phone, MapPin, FileText, Rocket, ShieldCheck } from "lucide-react";

const steps = [
  { icon: Phone, title: "Kontaktaufnahme", description: "Rufen Sie uns an oder nutzen Sie unser Kontaktformular – wir beraten Sie gerne." },
  { icon: MapPin, title: "Vor-Ort-Beratung & Aufmaß", description: "Wir besichtigen Ihr Objekt, nehmen Maß und analysieren Ihren individuellen Bedarf." },
  { icon: FileText, title: "Planung & Angebot", description: "Sie erhalten ein detailliertes Angebot mit transparenter Kalkulation und Fördermittelberatung." },
  { icon: Rocket, title: "Fachgerechte Installation", description: "Unsere Meister und Gesellen installieren Ihre neue Anlage termingerecht und sauber." },
  { icon: ShieldCheck, title: "Abnahme & Wartung", description: "Nach der Inbetriebnahme übernehmen wir die regelmäßige Wartung Ihrer Anlage." },
];

const TimelineItem = ({
  step,
  index,
  scrollYProgress,
}: {
  step: (typeof steps)[0];
  index: number;
  scrollYProgress: ReturnType<typeof useScroll>["scrollYProgress"];
}) => {
  const stepStart = index / steps.length;
  const stepMid = (index + 0.5) / steps.length;

  const circleBg = useTransform(scrollYProgress, [stepStart, stepMid], ["#ffffff", "hsl(24, 95%, 48%)"]);
  const circleBorder = useTransform(scrollYProgress, [stepStart, stepMid], ["#d1d5db", "hsl(24, 95%, 48%)"]);
  const textColor = useTransform(scrollYProgress, [stepStart, stepMid], ["#9ca3af", "#ffffff"]);

  const isEven = index % 2 === 0;

  const cardVariants = {
    hidden: { opacity: 0, x: isEven ? -50 : 50 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.6 } },
  };

  const mobileCardVariants = {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="relative">
      <div className="hidden md:grid grid-cols-[1fr_auto_1fr] gap-x-8 py-8">
        <div className={`flex items-center ${isEven ? "col-start-1 justify-end" : "col-start-3 justify-start"}`}>
          <motion.div
            className="w-full max-w-md"
            variants={cardVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
          >
            <motion.div
              className="rounded-xl border border-gray-300 bg-gray-50 p-6 text-left"
              whileHover={{
                y: -8,
                borderColor: "hsl(24, 95%, 48%)",
                boxShadow: "0 20px 40px -12px hsla(24, 95%, 48%, 0.15)",
                transition: { duration: 0.15 },
              }}
            >
              <div className="mb-3 flex items-center gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <step.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold font-sans">{step.title}</h3>
              </div>
              <p className="text-muted-foreground">{step.description}</p>
            </motion.div>
          </motion.div>
        </div>
        <div className="col-start-2 row-start-1 flex items-center justify-center h-full">
          <motion.div
            style={{ backgroundColor: circleBg, borderColor: circleBorder }}
            className="relative z-10 flex h-8 w-8 items-center justify-center rounded-full border-[3px]"
          >
            <motion.span style={{ color: textColor }} className="text-xs font-bold">{index + 1}</motion.span>
          </motion.div>
        </div>
      </div>

      <div className="md:hidden grid grid-cols-[28px_1fr] gap-x-4 items-start py-4">
        <div className="flex items-center justify-center pt-3">
          <motion.div
            style={{ backgroundColor: circleBg, borderColor: circleBorder }}
            className="relative z-10 flex h-7 w-7 items-center justify-center rounded-full border-[3px]"
          >
            <motion.span style={{ color: textColor }} className="text-[10px] font-bold">{index + 1}</motion.span>
          </motion.div>
        </div>
        <motion.div
          variants={mobileCardVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.5 }}
        >
          <motion.div
            className="rounded-xl border border-gray-300 bg-gray-50 p-4"
            whileHover={{
              y: -4,
              borderColor: "hsl(24, 95%, 48%)",
              boxShadow: "0 12px 24px -8px hsla(24, 95%, 48%, 0.15)",
              transition: { duration: 0.15 },
            }}
          >
            <div className="mb-2 flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <step.icon className="h-5 w-5" />
              </div>
              <h3 className="font-sans text-lg font-bold">{step.title}</h3>
            </div>
            <p className="text-sm text-muted-foreground">{step.description}</p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

const Timeline = () => {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start center", "end center"],
  });

  return (
    <section id="ablauf" className="relative overflow-hidden py-20">
      <div className="pointer-events-none absolute -left-20 -top-20 h-72 w-72 rounded-full bg-primary opacity-[0.07] blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 -right-20 h-72 w-72 rounded-full bg-accent opacity-[0.12] blur-3xl" />

      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl font-bold md:text-4xl">In fünf Schritten zur neuen Heizung</h2>
          <p className="mt-3 text-muted-foreground">Transparent, strukturiert und immer auf Augenhöhe</p>
        </motion.div>

        <div ref={targetRef} className="relative">
          <div className="pointer-events-none absolute bottom-0 left-[14px] top-0 w-1 -translate-x-1/2 rounded-full bg-gray-200 md:left-1/2 md:-translate-x-1/2">
            <motion.div
              className="h-full w-full origin-top rounded-full bg-primary"
              style={{ scaleY: scrollYProgress }}
            />
          </div>

          <div className="flex flex-col">
            {steps.map((step, index) => (
              <TimelineItem key={index} step={step} index={index} scrollYProgress={scrollYProgress} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Timeline;
