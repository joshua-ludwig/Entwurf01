import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { BadgeCheck, Shield, Wrench } from "lucide-react";
import heroImage from "@/assets/hero-heizung.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-[calc(100svh-64px)] overflow-hidden md:min-h-[calc(100vh-80px)]">
      {/* Background image */}
      <img
        src={heroImage}
        alt="Professionelle Heizungsinstallation durch SHK-Fachbetrieb"
        className="absolute inset-0 h-full w-full object-cover"
        width={1920}
        height={1080}
      />

      {/* Gradient overlays for text readability */}
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/20" />
      <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />

      {/* Content */}
      <div className="container relative flex min-h-[calc(100svh-64px)] items-center md:min-h-[calc(100vh-80px)]">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-xl py-16"
        >
          <div className="flex items-center gap-2 rounded-full border border-gray-300 bg-white/90 px-4 py-2 text-sm font-medium w-fit backdrop-blur-sm">
            <BadgeCheck className="h-4 w-4 text-primary" />
            Meisterbetrieb
          </div>

          <h1 className="mt-4 text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
            Ihr Heizungsbauer vor Ort
          </h1>
          <p className="mt-4 text-lg text-muted-foreground md:text-xl">
            Heizungsinstallation, Wartung & Notdienst – zuverlässig und kompetent.
            Ihr SHK-Fachbetrieb für moderne Heiztechnik.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-medium text-foreground/80">
              <Shield className="h-4 w-4 text-primary" />
              SHK-Fachbetrieb
            </div>
            <div className="flex items-center gap-2 text-sm font-medium text-foreground/80">
              <Wrench className="h-4 w-4 text-primary" />
              24h Notdienst
            </div>
          </div>

          <Button asChild size="lg" className="mt-8">
            <Link to="/kontakt">Jetzt Angebot anfordern</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
