import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "Wie oft sollte eine Heizung gewartet werden?",
    short: "Einmal jährlich – idealerweise vor der Heizsaison.",
    long: "Eine jährliche Wartung sorgt für optimale Effizienz, verlängert die Lebensdauer der Anlage und ist in vielen Fällen Voraussetzung für die Herstellergarantie.",
  },
  {
    q: "Welche Fördermittel gibt es für eine neue Heizung?",
    short: "Bis zu 70 % Förderung durch BEG und KfW möglich.",
    long: "Je nach Maßnahme und persönlicher Situation können Sie Zuschüsse oder günstige Kredite über die Bundesförderung für effiziente Gebäude (BEG) oder KfW-Programme erhalten. Wir beraten Sie individuell.",
  },
  {
    q: "Wie schnell sind Sie im Notfall vor Ort?",
    short: "In der Regel innerhalb von 1–2 Stunden.",
    long: "Unser 24h-Notdienst ist rund um die Uhr erreichbar. Bei Heizungsausfall oder Wasserrohrbruch sind wir schnellstmöglich bei Ihnen – auch an Wochenenden und Feiertagen.",
  },
  {
    q: "Lohnt sich eine Wärmepumpe für mein Haus?",
    short: "In den meisten Fällen ja – besonders bei guter Dämmung.",
    long: "Wärmepumpen arbeiten besonders effizient in gut gedämmten Gebäuden mit Fußbodenheizung. Aber auch im Altbau gibt es geeignete Lösungen. Wir prüfen die Machbarkeit kostenlos vor Ort.",
  },
  {
    q: "Wie lange dauert ein Heizungstausch?",
    short: "In der Regel 2–5 Werktage.",
    long: "Der genaue Zeitrahmen hängt von der Anlage und den baulichen Gegebenheiten ab. Vom Ausbau der alten Heizung bis zur Inbetriebnahme der neuen Anlage vergehen meist nur wenige Tage.",
  },
  {
    q: "Bieten Sie auch Badsanierungen an?",
    short: "Ja – vom barrierefreien Umbau bis zur Komplettsanierung.",
    long: "Wir planen und realisieren Ihr neues Bad inklusive Sanitärinstallation, Fliesen, Armaturen und Warmwasserbereitung. Alles aus einer Hand.",
  },
];

const FAQ = () => {
  return (
    <section id="faq" className="relative overflow-hidden py-20">
      <div className="pointer-events-none absolute -left-20 -top-20 h-72 w-72 rounded-full bg-accent opacity-[0.12] blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 -right-20 h-72 w-72 rounded-full bg-primary opacity-[0.07] blur-3xl" />

      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <h2 className="text-3xl font-bold md:text-4xl">Häufige Fragen</h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-3xl"
        >
          <Accordion type="single" collapsible className="flex flex-col gap-4">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="rounded-xl border border-gray-300 bg-gray-50 px-6 transition-all data-[state=open]:border-primary data-[state=open]:shadow-[0_20px_40px_-12px_hsla(24,95%,48%,0.15)]"
              >
                <AccordionTrigger className="py-5 text-left text-lg font-bold hover:no-underline">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5">
                  <p className="mb-2 font-medium text-foreground">{faq.short}</p>
                  <p className="text-muted-foreground">{faq.long}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQ;
