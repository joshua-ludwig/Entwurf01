import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ContactRequest {
  name: string;
  email: string;
  firma?: string;
  telefon?: string;
  objektart?: string;
  objekt?: string;
  nachricht?: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const resendKey = Deno.env.get("RESEND_API_KEY");
    if (!resendKey) {
      throw new Error("RESEND_API_KEY not configured");
    }

    const resend = new Resend(resendKey);
    const data: ContactRequest = await req.json();

    if (!data.name || !data.email) {
      return new Response(
        JSON.stringify({ error: "Name und E-Mail sind erforderlich" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const emailHtml = `
      <h2>Neue Kontaktanfrage – Lichius GmbH</h2>
      <table style="border-collapse:collapse;width:100%">
        <tr><td style="padding:8px;font-weight:bold">Name:</td><td style="padding:8px">${data.name}</td></tr>
        <tr><td style="padding:8px;font-weight:bold">E-Mail:</td><td style="padding:8px">${data.email}</td></tr>
        ${data.firma ? `<tr><td style="padding:8px;font-weight:bold">Firma:</td><td style="padding:8px">${data.firma}</td></tr>` : ""}
        ${data.telefon ? `<tr><td style="padding:8px;font-weight:bold">Telefon:</td><td style="padding:8px">${data.telefon}</td></tr>` : ""}
        ${data.objektart ? `<tr><td style="padding:8px;font-weight:bold">Objektart:</td><td style="padding:8px">${data.objektart}</td></tr>` : ""}
        ${data.objekt ? `<tr><td style="padding:8px;font-weight:bold">Objekt:</td><td style="padding:8px">${data.objekt}</td></tr>` : ""}
        ${data.nachricht ? `<tr><td style="padding:8px;font-weight:bold">Nachricht:</td><td style="padding:8px">${data.nachricht}</td></tr>` : ""}
      </table>
    `;

    const emailResponse = await resend.emails.send({
      from: "Lichius Website <onboarding@resend.dev>",
      to: ["info@lichius-gmbh.de"],
      subject: `Neue Anfrage von ${data.name}`,
      html: emailHtml,
    });

    console.log("Email sent:", emailResponse);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
